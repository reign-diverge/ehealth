import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const btn = "rounded-lg bg-teal-700 px-4 py-2 text-white hover:bg-teal-800 disabled:opacity-50";
const inp = "w-full rounded-lg border p-2";

function Auth({ onDone }) {
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ email: "", password: "", full_name: "", phone: "", city: "Harare", role: "patient", hpa_number: "", specialty: "" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const go = async () => {
    try {
      setErr("");
      if (mode === "signup") {
        await base44.auth.register({ email: f.email, password: f.password });
        const otp = prompt("Enter the verification code sent to your email");
        if (otp) await base44.auth.verifyOtp({ email: f.email, otpCode: otp });
      }
      await base44.auth.loginViaEmailPassword(f.email, f.password);
      if (mode === "signup") await base44.functions.invoke("register-profile", f);
      onDone();
    } catch (e) { setErr(e.message || "Failed"); }
  };
  return (
    <div className="mx-auto mt-16 max-w-sm space-y-3 p-4">
      <h1 className="text-2xl font-bold text-teal-800">ZimCare Online Hospital</h1>
      <input className={inp} placeholder="Email" value={f.email} onChange={set("email")} />
      <input className={inp} type="password" placeholder="Password" value={f.password} onChange={set("password")} />
      {mode === "signup" && <>
        <input className={inp} placeholder="Full name" value={f.full_name} onChange={set("full_name")} />
        <input className={inp} placeholder="Phone (+263…)" value={f.phone} onChange={set("phone")} />
        <input className={inp} placeholder="City" value={f.city} onChange={set("city")} />
        <select className={inp} value={f.role} onChange={set("role")}><option value="patient">Patient</option><option value="doctor">Doctor</option><option value="pharmacist">Pharmacist</option></select>
        {f.role !== "patient" && <input className={inp} placeholder="HPA / registration number (admin verifies)" value={f.hpa_number} onChange={set("hpa_number")} />}
      </>}
      {err && <p className="text-red-600">{err}</p>}
      <button className={btn + " w-full"} onClick={go}>{mode === "login" ? "Log in" : "Create account"}</button>
      <button className="w-full text-sm underline" onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "New here? Sign up" : "Have an account? Log in"}</button>
    </div>
  );
}

function Appointments({ me, profile }) {
  const [list, setList] = useState([]); const [docs, setDocs] = useState([]);
  const [f, setF] = useState({ doctor_email: "", type: "video", scheduled_at: "", clinic: "" });
  const [clin, setClin] = useState(null); const [cl, setCl] = useState({ notes: [], prescriptions: [] }); const [note, setNote] = useState(""); const [rx, setRx] = useState({ drug: "", dose: "", duration: "" });
  const [open, setOpen] = useState(null); const [msgs, setMsgs] = useState([]); const [text, setText] = useState(""); const [room, setRoom] = useState("");
  const load = async () => { setList(await base44.entities.Appointment.list("-scheduled_at")); setDocs((await base44.entities.Profile.filter({ role: "doctor", approved: true }))); };
  useEffect(() => { load(); }, []);
  const book = async () => { await base44.entities.Appointment.create({ ...f, patient_email: me.email, scheduled_at: new Date(f.scheduled_at).toISOString() }); load(); };
  const loadMsgs = async (id) => { const r = await base44.functions.invoke("phi", { action: "list_messages", appointment_id: id }); setMsgs(r.data?.messages || []); };
  const send = async () => { await base44.functions.invoke("phi", { action: "send_message", appointment_id: open, body: text }); setText(""); loadMsgs(open); };
  const loadClin = async (id) => { setClin(id); const r = await base44.functions.invoke("phi", { action: "list_clinical", appointment_id: id }); setCl(r.data || { notes: [], prescriptions: [] }); };
  const act = async (action, extra) => { await base44.functions.invoke("phi", { action, appointment_id: clin, ...extra }); loadClin(clin); };
  const join = async (id) => { const r = await base44.functions.invoke("video-room", { appointment_id: id }); setRoom(r.data?.url || ""); };
  return (
    <div className="space-y-4">
      {profile.role === "patient" && <div className="space-y-2 rounded-lg border p-3">
        <h2 className="font-semibold">Book a consultation</h2>
        <select className={inp} value={f.doctor_email} onChange={(e) => setF({ ...f, doctor_email: e.target.value })}><option value="">Choose doctor</option>{docs.map((d) => <option key={d.id} value={d.user_email}>{d.full_name} {d.specialty && `– ${d.specialty}`}</option>)}</select>
        <select className={inp} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="video">Video</option><option value="chat">Chat</option><option value="in_person">In person</option></select>
        {f.type === "in_person" && <input className={inp} placeholder="Clinic / hospital" value={f.clinic} onChange={(e) => setF({ ...f, clinic: e.target.value })} />}
        <input className={inp} type="datetime-local" value={f.scheduled_at} onChange={(e) => setF({ ...f, scheduled_at: e.target.value })} />
        <button className={btn} disabled={!f.doctor_email || !f.scheduled_at} onClick={book}>Request appointment</button>
      </div>}
      {list.map((a) => (
        <div key={a.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3">
          <span>{new Date(a.scheduled_at).toLocaleString()} · {a.type} · {a.status} · {profile.role === "doctor" ? a.patient_email : a.doctor_email}</span>
          <span className="flex gap-2">
            {profile.role === "doctor" && a.status === "requested" && <button className={btn} onClick={async () => { await base44.entities.Appointment.update(a.id, { status: "confirmed" }); load(); }}>Confirm</button>}
            {a.type === "video" && a.status === "confirmed" && <button className={btn} onClick={() => join(a.id)}>Join video</button>}
            <button className={btn} onClick={() => loadClin(a.id)}>Notes &amp; Rx</button>
            {a.type !== "in_person" && <button className={btn} onClick={() => { setOpen(a.id); loadMsgs(a.id); }}>Chat</button>}
          </span>
        </div>))}
      {clin && <div className="space-y-2 rounded-lg border p-3">
        <h3 className="font-semibold">Consultation notes &amp; prescriptions</h3>
        {cl.notes.map((n) => <p key={n.id} className="rounded bg-gray-50 p-2">{n.data}</p>)}
        {cl.prescriptions.map((r) => <p key={r.id} className="rounded bg-teal-50 p-2">Rx: {r.data.map((i) => `${i.drug} ${i.dose} × ${i.duration}`).join("; ")}</p>)}
        {profile.role === "doctor" && <>
          <textarea className={inp} placeholder="Clinical note (encrypted)" value={note} onChange={(e) => setNote(e.target.value)} />
          <button className={btn} disabled={!note} onClick={() => { act("save_note", { note }); setNote(""); }}>Save note</button>
          <div className="flex gap-2"><input className={inp} placeholder="Drug" value={rx.drug} onChange={(e) => setRx({ ...rx, drug: e.target.value })} /><input className={inp} placeholder="Dose" value={rx.dose} onChange={(e) => setRx({ ...rx, dose: e.target.value })} /><input className={inp} placeholder="Duration" value={rx.duration} onChange={(e) => setRx({ ...rx, duration: e.target.value })} /></div>
          <button className={btn} disabled={!rx.drug} onClick={() => { act("issue_rx", { items: [rx] }); setRx({ drug: "", dose: "", duration: "" }); }}>Issue prescription</button>
        </>}
      </div>}
      {room && <iframe title="video" src={room} allow="camera; microphone; fullscreen; display-capture" className="h-96 w-full rounded-lg border" />}
      {open && <div className="space-y-2 rounded-lg border p-3">
        <div className="max-h-64 space-y-1 overflow-y-auto">{msgs.map((m) => <p key={m.id} className={m.sender_email === me.email ? "text-right" : ""}><span className="inline-block rounded bg-gray-100 px-2 py-1">{m.body}</span></p>)}</div>
        <div className="flex gap-2"><input className={inp} value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message (encrypted)" /><button className={btn} onClick={send}>Send</button></div>
        <button className="text-sm underline" onClick={() => loadMsgs(open)}>Refresh</button>
      </div>}
    </div>
  );
}

function Pharmacy() {
  const [meds, setMeds] = useState([]); const [cart, setCart] = useState({}); const [delivery, setDelivery] = useState("pickup"); const [address, setAddress] = useState(""); const [res, setRes] = useState(null); const [mine, setMine] = useState([]); const [phone, setPhone] = useState(""); const [msg, setMsg] = useState("");
  const loadMine = async () => setMine((await base44.functions.invoke("phi", { action: "my_orders" })).data?.orders || []);
  useEffect(() => { loadMine(); }, []);
  const pay = async (id, action) => { const r = await base44.functions.invoke("pay-order", { action, order_id: id, phone }); setMsg(r.data?.error || r.data?.message || `Status: ${r.data?.status}`); loadMine(); };
  useEffect(() => { base44.entities.Medication.list().then(setMeds); }, []);
  const order = async () => { const items = Object.entries(cart).filter(([, q]) => q > 0).map(([id, qty]) => ({ id, qty })); const r = await base44.functions.invoke("phi", { action: "place_order", items, delivery, address }); setRes(r.data); setCart({}); };
  return (
    <div className="space-y-2">
      {meds.map((m) => <div key={m.id} className="flex items-center justify-between rounded-lg border p-3"><span>{m.name} · ${m.price_usd} {m.requires_prescription && "· Rx required"}</span><input type="number" min="0" className="w-20 rounded border p-1" value={cart[m.id] || 0} onChange={(e) => setCart({ ...cart, [m.id]: +e.target.value })} /></div>)}
      <select className={inp} value={delivery} onChange={(e) => setDelivery(e.target.value)}><option value="pickup">Pickup</option><option value="delivery">Delivery</option></select>
      {delivery === "delivery" && <input className={inp} placeholder="Delivery address" value={address} onChange={(e) => setAddress(e.target.value)} />}
      <button className={btn} onClick={order}>Place order</button>
      <div className="space-y-2 pt-4"><h2 className="font-semibold">My orders</h2>
        <input className={inp} placeholder="EcoCash number (077…/078…)" value={phone} onChange={(e) => setPhone(e.target.value)} />
        {mine.map((o) => <div key={o.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3"><span>{o.data.map((i) => `${i.name}×${i.qty}`).join(", ")} · ${o.total_usd} · {o.status.replace("_", " ")}</span>
          {o.status === "approved" && <button className={btn} disabled={!phone} onClick={() => pay(o.id, "init")}>Pay with EcoCash</button>}
          {o.poll_url && o.status === "approved" && <button className="underline" onClick={() => pay(o.id, "poll")}>Check payment</button>}</div>)}
        {msg && <p>{msg}</p>}</div>
      {res && <p>{res.error || `Order ${res.status.replace("_", " ")} · total $${res.total_usd}. Payment instructions follow once approved.`}</p>}
    </div>
  );
}

function Emergency({ profile }) {
  const [f, setF] = useState({ kind: "ambulance", location: "", details: "" }); const [done, setDone] = useState(false);
  const send = async () => { await base44.functions.invoke("phi", { action: "emergency", ...f, phone: profile.phone }); setDone(true); };
  return (
    <div className="space-y-2">
      <p className="rounded-lg bg-red-50 p-3 text-red-800">In a life-threatening emergency, also call your local emergency / ambulance number directly. Do not rely on this app alone.</p>
      <select className={inp} value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="ambulance">Ambulance</option><option value="urgent_advice">Urgent medical advice</option></select>
      <input className={inp} placeholder="Exact location / landmark" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} />
      <textarea className={inp} placeholder="What is happening?" value={f.details} onChange={(e) => setF({ ...f, details: e.target.value })} />
      <button className="rounded-lg bg-red-700 px-4 py-2 text-white" onClick={send}>Send emergency request</button>
      {done && <p className="font-semibold">Request sent to dispatch. Keep your phone on.</p>}
    </div>
  );
}

function Pharmacist() {
  const [orders, setOrders] = useState([]);
  const load = async () => setOrders((await base44.functions.invoke("phi", { action: "list_orders" })).data?.orders || []);
  useEffect(() => { load(); }, []);
  const decide = async (order_id, decision) => { await base44.functions.invoke("phi", { action: "review_order", order_id, decision }); load(); };
  return <div className="space-y-2"><h2 className="font-semibold">Orders awaiting prescription check</h2>{!orders.length && <p>None pending.</p>}
    {orders.map((o) => <div key={o.id} className="space-y-1 rounded-lg border p-3"><p>{o.patient_email}: {o.data.map((i) => `${i.name}×${i.qty}${i.rx ? " (Rx)" : ""}`).join(", ")}</p>
      <p className="text-sm">Active prescriptions: {o.prescriptions.flat().map((i) => `${i.drug} ${i.dose}`).join("; ") || "none on file"}</p>
      <button className={btn} onClick={() => decide(o.id, "approved")}>Approve</button> <button className="rounded-lg border px-4 py-2" onClick={() => decide(o.id, "rejected")}>Reject</button></div>)}</div>;
}

function Dispatcher() {
  const [rows, setRows] = useState([]);
  const load = async () => setRows((await base44.functions.invoke("phi", { action: "list_emergencies" })).data?.requests || []);
  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, []);
  const set = async (id, status) => { await base44.functions.invoke("phi", { action: "set_emergency", id, status }); load(); };
  return <div className="space-y-2"><h2 className="font-semibold">Open emergency requests</h2>{!rows.length && <p>None open.</p>}
    {rows.map((r) => <div key={r.id} className="space-y-1 rounded-lg border border-red-300 p-3"><p className="font-semibold">{r.kind} · {r.phone || r.patient_email}</p><p>{r.location}</p><p>{r.details}</p>
      <button className={btn} onClick={() => set(r.id, "dispatched")}>Mark dispatched</button> <button className="rounded-lg border px-4 py-2" onClick={() => set(r.id, "closed")}>Close</button></div>)}</div>;
}

function Admin() {
  const [pending, setPending] = useState([]); const [m, setM] = useState({ name: "", price_usd: "", requires_prescription: false }); const [info, setInfo] = useState("");
  const load = async () => setPending(await base44.entities.Profile.filter({ approved: false }));
  useEffect(() => { load(); }, []);
  return <div className="space-y-4"><div><h2 className="font-semibold">Pending verification</h2>
    {pending.map((p) => <div key={p.id} className="flex items-center justify-between rounded-lg border p-3"><span>{p.full_name} · {p.role} · {p.hpa_number || "no reg. no."} · {p.user_email}</span><button className={btn} onClick={async () => { await base44.entities.Profile.update(p.id, { approved: true }); load(); }}>Approve</button></div>)}</div>
    <div className="space-y-2"><h2 className="font-semibold">Add medication</h2><input className={inp} placeholder="Name" value={m.name} onChange={(e) => setM({ ...m, name: e.target.value })} /><input className={inp} type="number" placeholder="Price USD" value={m.price_usd} onChange={(e) => setM({ ...m, price_usd: e.target.value })} />
      <label className="flex gap-2"><input type="checkbox" checked={m.requires_prescription} onChange={(e) => setM({ ...m, requires_prescription: e.target.checked })} />Prescription only</label>
      <button className={btn} disabled={!m.name || !m.price_usd} onClick={async () => { await base44.entities.Medication.create({ ...m, price_usd: +m.price_usd }); setM({ name: "", price_usd: "", requires_prescription: false }); setInfo("Medication added"); }}>Add</button></div>
    <button className={btn} onClick={async () => setInfo(`Reminders sent: ${(await base44.functions.invoke("send-reminders", {})).data?.sent ?? 0}`)}>Send 24h appointment reminders</button>{info && <p>{info}</p>}</div>;
}

export default function App() {
  const [me, setMe] = useState(null); const [profile, setProfile] = useState(null); const [tab, setTab] = useState("appointments"); const [ready, setReady] = useState(false);
  const boot = async () => {
    try { const u = await base44.auth.me(); setMe(u); setProfile((await base44.entities.Profile.filter({ user_email: u.email }))[0] || null); } catch { setMe(null); }
    setReady(true);
  };
  useEffect(() => { boot(); }, []);
  if (!ready) return <p className="p-6">Loading…</p>;
  if (!me) return <Auth onDone={boot} />;
  if (me.role === "admin") return <div className="mx-auto max-w-3xl space-y-4 p-4"><h1 className="text-xl font-bold text-teal-800">ZimCare Admin</h1><Admin /></div>;
  if (!profile) return <div className="p-6">Finishing your profile… <button className={btn} onClick={boot}>Retry</button></div>;
  if (!profile.approved) return <div className="p-6">Your {profile.role} account is awaiting verification by an administrator. <button className="underline" onClick={() => base44.auth.logout()}>Log out</button></div>;
  const extra = { pharmacist: ["pharmacist", "Order review"], dispatcher: ["dispatcher", "Dispatch"] }[profile.role];
  const tabs = [...(extra ? [extra] : []), ["appointments", "Consultations"], ["pharmacy", "Pharmacy"], ["emergency", "Emergency"]];
  return (
    <div className="mx-auto max-w-3xl space-y-4 p-4">
      <header className="flex items-center justify-between"><h1 className="text-xl font-bold text-teal-800">ZimCare</h1><button className="text-sm underline" onClick={() => base44.auth.logout()}>Log out ({profile.full_name || me.email})</button></header>
      <nav className="flex gap-2">{tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-3 py-1 ${tab === k ? "bg-teal-700 text-white" : "border"}`}>{l}</button>)}</nav>
      {tab === "appointments" && <Appointments me={me} profile={profile} />}
      {tab === "pharmacist" && <Pharmacist />}
      {tab === "dispatcher" && <Dispatcher />}
      {tab === "pharmacy" && <Pharmacy />}
      {tab === "emergency" && <Emergency profile={profile} />}
    </div>
  );
}
