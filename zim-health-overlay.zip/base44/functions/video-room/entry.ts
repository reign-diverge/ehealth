import { createClientFromRequest } from "npm:@base44/sdk";
// Needs secret DAILY_API_KEY (daily.co). Only the appointment's patient or doctor gets a room link.
Deno.serve(async (req) => {
  const b44 = createClientFromRequest(req);
  const user = await b44.auth.me();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { appointment_id } = await req.json();
  const a = await b44.asServiceRole.entities.Appointment.get(appointment_id);
  if (!a || a.type !== "video" || (a.patient_email !== user.email && a.doctor_email !== user.email))
    return Response.json({ error: "Forbidden" }, { status: 403 });
  const headers = { Authorization: `Bearer ${Deno.env.get("DAILY_API_KEY")}`, "Content-Type": "application/json" };
  const name = `appt-${a.id}`;
  let room = await fetch(`https://api.daily.co/v1/rooms/${name}`, { headers }).then((r) => (r.ok ? r.json() : null));
  if (!room) room = await fetch("https://api.daily.co/v1/rooms", { method: "POST", headers,
    body: JSON.stringify({ name, privacy: "private", properties: { exp: Math.floor(Date.now() / 1000) + 7200, enable_chat: true } }) }).then((r) => r.json());
  const tok = await fetch("https://api.daily.co/v1/meeting-tokens", { method: "POST", headers,
    body: JSON.stringify({ properties: { room_name: name, user_name: user.full_name || user.email, is_owner: user.email === a.doctor_email, exp: Math.floor(Date.now() / 1000) + 7200 } }) }).then((r) => r.json());
  return Response.json({ url: `${room.url}?t=${tok.token}` });
});
