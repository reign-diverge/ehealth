import { createClientFromRequest } from "npm:@base44/sdk";
// Patients are auto-approved. Doctors/pharmacists are created unapproved; an admin approves
// after checking their HPA/pharmacy registration (set approved=true in the dashboard).
Deno.serve(async (req) => {
  const b44 = createClientFromRequest(req);
  const user = await b44.auth.me();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { role = "patient", full_name, phone, city, specialty, hpa_number } = await req.json();
  if (!["patient", "doctor", "pharmacist"].includes(role)) return Response.json({ error: "Invalid role" }, { status: 400 });
  const existing = await b44.asServiceRole.entities.Profile.filter({ user_email: user.email });
  if (existing.length) return Response.json({ profile: existing[0] });
  const profile = await b44.asServiceRole.entities.Profile.create({
    user_email: user.email, role, full_name, phone, city, specialty, hpa_number, approved: role === "patient",
  });
  return Response.json({ profile });
});
