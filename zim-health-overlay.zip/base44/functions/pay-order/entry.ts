import { createClientFromRequest } from "npm:@base44/sdk";
// EcoCash via Paynow Zimbabwe (mobile express). Secrets: PAYNOW_ID, PAYNOW_KEY, APP_URL.
// Verify field order/hash against Paynow's current docs and test with their sandbox before going live.
const sha = async (s: string) => [...new Uint8Array(await crypto.subtle.digest("SHA-512", new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
Deno.serve(async (req) => {
  try {
    const b44 = createClientFromRequest(req);
    const user = await b44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const { action, order_id, phone } = await req.json();
    const o = await b44.asServiceRole.entities.MedOrder.get(order_id);
    if (!o || o.patient_email !== user.email) return Response.json({ error: "Forbidden" }, { status: 403 });
    const key = Deno.env.get("PAYNOW_KEY")!;
    if (action === "init") {
      if (o.status !== "approved") return Response.json({ error: "Order not approved for payment" }, { status: 400 });
      const f: Record<string, string> = { id: Deno.env.get("PAYNOW_ID")!, reference: `order-${o.id}`, amount: Number(o.total_usd).toFixed(2),
        additionalinfo: "ZimCare order", returnurl: Deno.env.get("APP_URL")!, resulturl: Deno.env.get("APP_URL")!, authemail: user.email, phone, method: "ecocash", status: "Message" };
      f.hash = await sha(Object.values(f).slice(0, 10).join("") + key);
      const txt = await (await fetch("https://www.paynow.co.zw/interface/remotetransaction", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(f) })).text();
      const r = Object.fromEntries(new URLSearchParams(txt));
      if (String(r.status).toLowerCase() !== "ok") return Response.json({ error: r.error || "Payment could not start" }, { status: 400 });
      await b44.asServiceRole.entities.MedOrder.update(o.id, { poll_url: r.pollurl });
      return Response.json({ ok: true, message: "Approve the EcoCash prompt on your phone, then tap Check payment." });
    }
    if (action === "poll") {
      if (!o.poll_url) return Response.json({ status: o.status });
      const r = Object.fromEntries(new URLSearchParams(await (await fetch(o.poll_url, { method: "POST" })).text()));
      if (["paid", "delivered"].includes(String(r.status).toLowerCase())) await b44.asServiceRole.entities.MedOrder.update(o.id, { status: "paid" });
      return Response.json({ status: String(r.status).toLowerCase() === "paid" ? "paid" : o.status, gateway: r.status });
    }
    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) { return Response.json({ error: (e as Error).message }, { status: 500 }); }
});
