import { createClientFromRequest } from "npm:@base44/sdk";
// Admin-triggered (dashboard button) or call on a schedule from any cron service. Emails contain time only, no health details.
Deno.serve(async (req) => {
  const b44 = createClientFromRequest(req);
  const user = await b44.auth.me();
  if (user?.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
  const sr = b44.asServiceRole, now = Date.now();
  const due = (await sr.entities.Appointment.filter({ status: "confirmed", reminded: false })).filter((a: any) => { const t = new Date(a.scheduled_at).getTime(); return t > now && t - now < 24 * 3600e3; });
  for (const a of due) {
    const when = new Date(a.scheduled_at).toLocaleString("en-GB", { timeZone: "Africa/Harare" });
    for (const to of [a.patient_email, a.doctor_email])
      await sr.integrations.Core.SendEmail({ to, subject: "ZimCare appointment reminder", body: `Reminder: your ${a.type.replace("_", "-")} consultation is on ${when} (Harare time). Log in to ZimCare to join or view details.` });
    await sr.entities.Appointment.update(a.id, { reminded: true });
  }
  return Response.json({ sent: due.length });
});
