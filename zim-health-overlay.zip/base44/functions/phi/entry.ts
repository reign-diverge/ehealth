import { createClientFromRequest } from "npm:@base44/sdk";
// All protected health information passes through here: authorise -> encrypt/decrypt -> store.
// Key: 32 random bytes, base64, in secret PHI_ENCRYPTION_KEY (openssl rand -base64 32).
const b64 = (u: Uint8Array) => btoa(String.fromCharCode(...u));
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function key() {
  const raw = Deno.env.get("PHI_ENCRYPTION_KEY");
  if (!raw) throw new Error("PHI_ENCRYPTION_KEY not set");
  return crypto.subtle.importKey("raw", unb64(raw), "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function enc(text: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await key(), new TextEncoder().encode(text)));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return "v1:" + b64(out);
}
async function dec(s: string) {
  const buf = unb64(s.slice(3));
  return new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: buf.slice(0, 12) }, await key(), buf.slice(12)));
}

Deno.serve(async (req) => {
  try {
    const b44 = createClientFromRequest(req);
    const user = await b44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const sr = b44.asServiceRole.entities;
    const { action, ...p } = await req.json();
    const profile = (await sr.Profile.filter({ user_email: user.email }))[0];

    const apptFor = async (id: string) => {
      const a = await sr.Appointment.get(id);
      if (!a || (a.patient_email !== user.email && a.doctor_email !== user.email)) return null;
      return a;
    };

    if (action === "send_message") {
      const a = await apptFor(p.appointment_id);
      if (!a || !p.body?.trim()) return Response.json({ error: "Forbidden" }, { status: 403 });
      await sr.Message.create({ appointment_id: a.id, patient_email: a.patient_email, doctor_email: a.doctor_email, sender_email: user.email, body_enc: await enc(p.body.slice(0, 4000)) });
      return Response.json({ ok: true });
    }
    if (action === "list_messages") {
      const a = await apptFor(p.appointment_id);
      if (!a) return Response.json({ error: "Forbidden" }, { status: 403 });
      const rows = await sr.Message.filter({ appointment_id: a.id }, "created_date");
      return Response.json({ messages: await Promise.all(rows.map(async (m: any) => ({ id: m.id, sender_email: m.sender_email, at: m.created_date, body: await dec(m.body_enc) }))) });
    }
    if (action === "place_order") {
      const meds = await sr.Medication.list();
      let total = 0; const items: any[] = [];
      for (const it of p.items || []) {
        const m = meds.find((x: any) => x.id === it.id);
        if (!m || !m.in_stock) continue;
        total += m.price_usd * (it.qty || 1);
        items.push({ name: m.name, qty: it.qty || 1, rx: m.requires_prescription });
      }
      if (!items.length) return Response.json({ error: "No valid items" }, { status: 400 });
      const needsReview = items.some((i) => i.rx); // pharmacist must verify a prescription before approval
      const order = await sr.MedOrder.create({
        patient_email: user.email, items_enc: await enc(JSON.stringify(items)), total_usd: total, delivery: p.delivery || "pickup",
        address_enc: p.address ? await enc(p.address) : "", status: needsReview ? "pending_review" : "approved",
      });
      return Response.json({ order_id: order.id, status: order.status, total_usd: total });
    }
    if (action === "emergency") {
      const r = await sr.EmergencyRequest.create({
        patient_email: user.email, kind: p.kind === "urgent_advice" ? "urgent_advice" : "ambulance", phone: p.phone || profile?.phone || "",
        location_enc: await enc(p.location || ""), details_enc: await enc(p.details || ""),
      });
      return Response.json({ id: r.id, status: "open" });
    }
    if (action === "list_emergencies") { // dispatchers only
      if (profile?.role !== "dispatcher" || !profile.approved) return Response.json({ error: "Forbidden" }, { status: 403 });
      const rows = await sr.EmergencyRequest.filter({ status: "open" }, "-created_date");
      return Response.json({ requests: await Promise.all(rows.map(async (r: any) => ({ ...r, location_enc: undefined, details_enc: undefined, location: await dec(r.location_enc), details: await dec(r.details_enc) }))) });
    }
    const isRole = (r: string) => profile?.role === r && profile.approved;
    const parse = async (rows: any[], f: string) => Promise.all(rows.map(async (r: any) => ({ ...r, [f]: undefined, data: JSON.parse(await dec(r[f])) })));

    if (action === "save_note" || action === "issue_rx") {
      const a = await apptFor(p.appointment_id);
      if (!a || !isRole("doctor") || a.doctor_email !== user.email) return Response.json({ error: "Forbidden" }, { status: 403 });
      const base = { appointment_id: a.id, patient_email: a.patient_email, doctor_email: a.doctor_email };
      if (action === "save_note") await sr.ConsultationNote.create({ ...base, note_enc: await enc(JSON.stringify(String(p.note || "").slice(0, 8000))) });
      else await sr.Prescription.create({ ...base, items_enc: await enc(JSON.stringify(p.items || [])) });
      return Response.json({ ok: true });
    }
    if (action === "list_clinical") {
      const a = await apptFor(p.appointment_id);
      if (!a) return Response.json({ error: "Forbidden" }, { status: 403 });
      const [n, r] = await Promise.all([sr.ConsultationNote.filter({ appointment_id: a.id }, "-created_date"), sr.Prescription.filter({ appointment_id: a.id }, "-created_date")]);
      return Response.json({ notes: await parse(n, "note_enc"), prescriptions: await parse(r, "items_enc") });
    }
    if (action === "my_orders") {
      return Response.json({ orders: await parse(await sr.MedOrder.filter({ patient_email: user.email }, "-created_date"), "items_enc") });
    }
    if (action === "list_orders") { // pharmacists: orders awaiting prescription check + that patient's active prescriptions
      if (!isRole("pharmacist")) return Response.json({ error: "Forbidden" }, { status: 403 });
      const orders = await parse(await sr.MedOrder.filter({ status: "pending_review" }, "created_date"), "items_enc");
      for (const o of orders) o.prescriptions = (await parse(await sr.Prescription.filter({ patient_email: o.patient_email, status: "active" }), "items_enc")).map((x: any) => x.data);
      return Response.json({ orders });
    }
    if (action === "review_order") {
      if (!isRole("pharmacist") || !["approved", "rejected"].includes(p.decision)) return Response.json({ error: "Forbidden" }, { status: 403 });
      await sr.MedOrder.update(p.order_id, { status: p.decision });
      return Response.json({ ok: true });
    }
    if (action === "set_emergency") {
      if (!isRole("dispatcher") || !["dispatched", "closed"].includes(p.status)) return Response.json({ error: "Forbidden" }, { status: 403 });
      await sr.EmergencyRequest.update(p.id, { status: p.status });
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
});
