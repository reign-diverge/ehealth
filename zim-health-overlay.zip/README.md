# ZimCare – Zimbabwe online hospital (Base44 overlay)

1. `npm install --save-dev base44 && npx base44 login`
2. `npx base44 create zim-health -p ./zim-health -t backend-and-client`
3. Copy `base44/` and `src/App.jsx` from this folder over the new project (replace the template App.jsx).
4. Secrets (add `PAYNOW_ID`, `PAYNOW_KEY`, `APP_URL`=your deployed site URL; register a Paynow Zimbabwe merchant account first and test in their sandbox):
   - `openssl rand -base64 32` -> `npx base44 secrets set PHI_ENCRYPTION_KEY=<value>` (back it up; losing it makes data unreadable)
   - `npx base44 secrets set DAILY_API_KEY=<key from daily.co>`
5. `npx base44 auth password-login enable`, then `npm run build && npx base44 deploy -y`
6. In the dashboard: add Medication rows; approve doctors/pharmacists/dispatchers by setting Profile.approved = true (verify HPA/registration first). Create dispatcher Profiles manually.

Admin = a Base44 admin user (Admin dashboard: approvals, medications, reminders). Reminders run when the admin taps the button; call the `send-reminders` function from any scheduler for automatic daily runs. Not included yet: patient records export, doctor availability slots, refunds, audit-log viewer.
